export const PRODUCTS_BASEURL = 'https://rabbitmart-products.vercel.app/products'
export const SHIPPING_BASEURL = 'https://rabbitmart-shipping.vercel.app/shipping'
export const NOTIFICATIONS_BASEURL = 'https://rabbitmart-notifications.vercel.app/notifications'
export const USER_BASEURL = 'https://rabbitmart-users.vercel.app/me'