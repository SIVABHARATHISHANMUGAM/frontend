export const SEARCH_HIDDEN = 0;
export const SEARCH_VISIBLE = 1;